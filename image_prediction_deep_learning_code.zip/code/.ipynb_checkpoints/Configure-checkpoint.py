import os
import argparse




def configure():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--resume', '-r', action='store_true',
                    help='resume from checkpoint')
    parser.add_argument("--save_interval", type=int, default=10,
                        help='save the checkpoint when epoch MOD save_interval == 0')
    parser.add_argument("--batch_size", type=int, default=256, help='training batch size')
    parser.add_argument("--weight_decay", type=float, default=1e-4, help='weight decay rate')
    # parser.add_argument("--modeldir", type=str, default='model_v1', help='model directory')
    parser.add_argument("--maxepochs", type=int, default=10, help='maxepochs')
    parser.add_argument("--modeldir", type=str, default="C:/Users/Piyush Nayak/OneDrive/Documents/TAMU assignments/DL/Final Project/model_v11", help='model directory')
    return parser.parse_args()