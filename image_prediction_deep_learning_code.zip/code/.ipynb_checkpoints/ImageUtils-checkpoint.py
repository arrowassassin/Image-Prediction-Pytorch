import numpy as np


"""This script implements the functions for data augmentation
and preprocessing.
"""

def parse_record(record, training):
    """Parse a record to an image and perform data preprocessing.

    Args:
        record: An array of shape [3072,]. One row of the x_* matrix.
        training: A boolean. Determine whether it is in training mode.

    Returns:
        image: An array of shape [32, 32, 3].
    """
    # Reshape from [depth * height * width] to [depth, height, width].
    depth_major = record.reshape((3, 32, 32))

    # Convert from [depth, height, width] to [height, width, depth]
    image = np.transpose(depth_major, [1, 2, 0])

    image = preprocess_image(image, training)

    # Convert from [height, width, depth] to [depth, height, width]
    

    image = preprocess_image(image, training) # If any.
    
    image = np.transpose(image, [2, 0, 1])

    return image


def preprocess_image(image, training):
    """Preprocess a single image of shape [height, width, depth].

    Args:
        image: An array of shape [32, 32, 3].
        training: A boolean. Determine whether it is in training mode.

    Returns:
        image: An array of shape [32, 32, 3]. The processed image.
    """
    if training:
        # Resize the image to add four extra pixels on each side.
        canvas = np.zeros((40, 40, 3))

        canvas[4:36, 4:36] = image
        # Randomly crop a [32, 32] section of the image.
        
        x = np.random.randint(0,8)
        y = np.random.randint(0,8)
        
        canvas = canvas[x:x+32, y:y+32]
        

        # Randomly flip the image horizontally.
        
        canvas = np.fliplr(canvas)

    # Subtract off the mean and divide by the standard deviation of the pixels.
        image = canvas
    np.seterr(divide='ignore', invalid='ignore')
    mean = np.mean(image, axis=(1,2), keepdims=True)
    std = np.std(image, axis=(1,2), keepdims=True)
    image = (image - mean) / std
    image[np.isnan(image)] = 0.0
    
    return image


# Other functions
### YOUR CODE HERE

### END CODE HERE